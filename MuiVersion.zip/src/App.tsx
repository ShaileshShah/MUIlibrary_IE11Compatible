import React from 'react';
import logo from './logo.svg';
import './App.css';
import ContainedButtons from './button';
function App() {
  return (
    <div className="App">
      <header className="App-header">
       <ContainedButtons></ContainedButtons>
      </header>
    </div>
  );
}

export default App;
